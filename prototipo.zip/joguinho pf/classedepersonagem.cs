﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    public class classedepersonagem
    {
        public string name;
        public int ataque;
        public int vida;
        public double velocidade;
        public int mana;
        public int escolha;
        public string numeros;
        public int buff;
        public int duraçãodobuff;
        public int debuff;
        public int duraçãododebuff;


        public static void Ataque(string a, int i, object jogador)
        {
           // a que se torna c é o personagem que está a ser atacado
           // i é o personagem atacando
           // jogador é o jogador atacando
           // g é pra calcular a diferença entre o buff e o debuff caso ambos estejam ativos

            int c = int.Parse(a);

            int d=0;
            int g = 0;



            if (jogador == Program.jogador1)
            {
                //jogador1
                if (Program.jogador1.personagens[i].duraçãodobuff > 0 || Program.jogador1.personagens[i].duraçãododebuff > 0)
                {
                    if(Program.jogador1.personagens[i].duraçãododebuff > 0 && Program.jogador1.personagens[i].duraçãodobuff > 0)
                    {
                        g = Program.jogador1.personagens[i].buff - Program.jogador1.personagens[i].debuff;

                        d = g + Program.jogador1.personagens[i].ataque;

                        Program.jogador2.personagens[c].vida -= d;

                        Program.jogador1.personagens[i].duraçãodobuff -= 1;

                        Program.jogador1.personagens[i].duraçãododebuff -= 1;


                    }
                    else if (Program.jogador1.personagens[i].duraçãodobuff > 0)
                    {
                        d = Program.jogador1.personagens[i].ataque + Program.jogador1.personagens[i].buff;

                        Program.jogador2.personagens[c].vida -= d;

                        Program.jogador1.personagens[i].duraçãodobuff -= 1;


                    }
                    else 
                    { d = Program.jogador1.personagens[i].ataque - Program.jogador1.personagens[i].debuff;

                        Program.jogador2.personagens[c].vida -= d;

                        Program.jogador1.personagens[i].duraçãododebuff -= 1;

                    }

                       
                      
                    Program.jogador1.personagens[i].velocidade -= 1;
                }
                else 
                { 
                    //caso não tenha nehum buff ou só vai usar o ataque
                 Program.jogador2.personagens[c].vida -= Program.jogador1.personagens[i].ataque;

                    Program.jogador1.personagens[i].velocidade -= 1;
                }
            }
            else 
            {
                //jogador2
                if (Program.jogador2.personagens[i].duraçãodobuff > 0 || Program.jogador2.personagens[i].duraçãododebuff > 0)
                {
                    if (Program.jogador2.personagens[i].duraçãododebuff > 0 && Program.jogador2.personagens[i].duraçãodobuff > 0)
                    {
                        g = Program.jogador2.personagens[i].buff - Program.jogador2.personagens[i].debuff;

                        d = g + Program.jogador2.personagens[i].ataque;

                        Program.jogador1.personagens[c].vida -= d;

                        Program.jogador2.personagens[i].duraçãodobuff -= 1;

                        Program.jogador2.personagens[i].duraçãododebuff -= 1;


                    }
                    else if (Program.jogador2.personagens[i].duraçãodobuff > 0)
                    {
                        d = Program.jogador2.personagens[i].ataque + Program.jogador2.personagens[i].buff;

                        Program.jogador1.personagens[c].vida -= d;

                        Program.jogador2.personagens[i].duraçãodobuff -= 1;


                    }
                    else
                    {
                        d = Program.jogador2.personagens[i].ataque - Program.jogador2.personagens[i].debuff;

                        Program.jogador1.personagens[c].vida -= d;

                        Program.jogador2.personagens[i].duraçãododebuff -= 1;

                    }



                    Program.jogador2.personagens[i].velocidade -= 1;
                }
                else
                {
                    //caso não tenha nehum buff só vai usar o ataque
                    Program.jogador1.personagens[c].vida -= Program.jogador2.personagens[i].ataque;

                    Program.jogador2.personagens[i].velocidade -= 1;
                }
            }
        }
    }
}