﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace joguinho_pf
{
    internal class Assassino:classedepersonagem
    {
        public Assassino()
        {
            name = "Assassino";
            ataque = 25;
            vida = 100;
            velocidade = 1.5;
            mana = 1;
            escolha = 0;
            numeros = "";
            buff = 0;
            duraçãodobuff=0;
            debuff =0;
            duraçãododebuff = 0 ;



        }

        
        

    }
}
