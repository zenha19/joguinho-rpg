﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace joguinho_pf
{
    internal class Tanque:classedepersonagem
    {
        public Tanque()
        {
            name = "tanque";
            ataque = 25;
            vida = 125;
            velocidade = 1;
            mana = 1;
            escolha = 0;
            buff = 0;
            duraçãodobuff = 0;
            debuff = 0;
            duraçãododebuff = 0;
        }
    } 
}
