﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    internal class escolhas
    {

        public static void escolha(object c,int b) 
        
        {
            string z;
            string a;
            if (c == Program.jogador1)
            {
                //vereficção se o jogador vai atacr ou usar poção

                Console.Clear();
                Console.WriteLine("personagem de " + Program.jogador1.nome);

                switch (b)
                {
                    case 0:
                        Console.WriteLine("turno do "+Program.jogador1.personagens[0].name );
                        break;
                    case 1:
                        Console.WriteLine("turno do " + Program.jogador1.personagens[1].name );
                        break;
                    default:
                        Console.WriteLine("turno do " + Program.jogador1.personagens[2].name );
                        break;
                }

                do
                {
                    Console.WriteLine("1 atacar,2 usar poção");
                    z = Console.ReadLine();
                }while (z != "1" && z!= "2");
                if (z == "1" )
                {
                    //caso ele ataque
                   

                    switch(b)
                    {
                        case 0:
                            Console.WriteLine(Program.jogador1.personagens[0].name+ " está atacando" );
                            break;
                            case 1:
                            Console.WriteLine(Program.jogador1.personagens[1].name + " está atacando");
                            break;
                        default:
                            Console.WriteLine(Program.jogador1.personagens[2].name + " está atacando");
                            break;
                    }
                    Console.WriteLine("qual personagem deseja atacar ?");
                    Console.ReadLine();

                    do {
                        Console.WriteLine("0 " + Program.jogador2.personagens[0].name + "." + Program.jogador2.personagens[0].vida + "HP");
                        Console.WriteLine("1 " + Program.jogador2.personagens[1].name + "." + Program.jogador2.personagens[1].vida + "HP");
                        Console.WriteLine("2 " + Program.jogador2.personagens[2].name + "." + Program.jogador2.personagens[2].vida + "HP");
                        a = Console.ReadLine();
                    }while (a != "0" && a!= "1 " && a != "2");
                    classedepersonagem.Ataque(a, b, c);

                }
                else
                {
                    //caso ele escolha poção
                    switch (b)
                    {
                        case 0:
                            Console.WriteLine(Program.jogador1.personagens[0].name + " está dando buffs");
                            break;
                        case 1:
                            Console.WriteLine(Program.jogador1.personagens[1].name + " está dando buffs");
                            break;
                        default:
                            Console.WriteLine(Program.jogador1.personagens[2].name + " está dando buffs");
                            break;
                    }
                   

                    Console.WriteLine("qual buff deseja dar ?");
                    Console.ReadLine();

                    do
                    {
                        Console.WriteLine("1 vida");
                        Console.WriteLine("2 velocidade");
                        Console.WriteLine("3 ataque");
                        a = Console.ReadLine();
                    } while (a != "1" && a != "2 " && a != "3");

                    if (a == "1")
                    {
                        Pocoes.Vida(Program.jogador1,b);
                    }
                    else if (a == "2")
                    {
                      Pocoes.Velocidade(Program.jogador1,b);
                    }
                    else 
                    {
                        Pocoes.Ataque(Program.jogador1, b);
                    }
                    





                }



            }
            else 
            {
                Console.Clear();
                Console.WriteLine("personagem de " + Program.jogador2.nome);

                switch (b)
                {
                    case 0:
                        Console.WriteLine("turno do " + Program.jogador2.personagens[0].name);
                        break;
                    case 1:
                        Console.WriteLine("turno do " + Program.jogador2.personagens[1].name);
                        break;
                    default:
                        Console.WriteLine("turno do " + Program.jogador2.personagens[2].name);
                        break;
                }
                //vereficção se o jogador vai atacr ou usar poção
                z = "";
                do
                {
                    Console.WriteLine("1 atacar,2 usar poção");
                    z = Console.ReadLine();
                } while (z != "1" && z != "2");

                if (z == "1")
                {
                    //caso ele ataque


                    switch (b)
                    {
                        case 0:
                            Console.WriteLine(Program.jogador2.personagens[0].name + " está atacando");
                            break;
                        case 1:
                            Console.WriteLine(Program.jogador2.personagens[1].name + " está atacando");
                            break;
                        default:
                            Console.WriteLine(Program.jogador2.personagens[2].name + " está atacando");
                            break;
                    }

                    Console.WriteLine("qual personagem deseja atacar ?");
                    Console.ReadLine();

                    do
                    {
                        Console.WriteLine("0 " + Program.jogador1.personagens[0].name + "." + Program.jogador1.personagens[0].vida + "HP");
                        Console.WriteLine("1 " + Program.jogador1.personagens[1].name + "." + Program.jogador1.personagens[1].vida + "HP");
                        Console.WriteLine("2 " + Program.jogador1.personagens[2].name + "." + Program.jogador1.personagens[2].vida + "HP");
                        a = Console.ReadLine();
                    } while (a != "0" && a != "1 " && a != "2");
                    classedepersonagem.Ataque(a, b, c);

                }
                else
                {
                    switch (b)
                    {
                        case 0:
                            Console.WriteLine(Program.jogador2.personagens[0].name + " está dando buffs");
                            break;
                        case 1:
                            Console.WriteLine(Program.jogador2.personagens[1].name + " está dando buffs");
                            break;
                        default:
                            Console.WriteLine(Program.jogador2.personagens[2].name + " está dando buffs");
                            break;
                    }


                    Console.WriteLine("qual buff deseja dar ?");
                    Console.ReadLine();

                    do
                    {
                        Console.WriteLine("1 vida");
                        Console.WriteLine("2 velocidade");
                        Console.WriteLine("3 ataque");
                        a = Console.ReadLine();
                    } while (a != "1" && a != "2 " && a != "3");

                    if (a == "1")
                    {
                        Pocoes.Vida(Program.jogador2, b);
                    }
                    else if (a == "2")
                    {
                        Pocoes.Velocidade(Program.jogador2, b);
                    }
                    else
                    {
                        Pocoes.Ataque(Program.jogador2, b);
                    }
                }

            }
        }
    }
}
