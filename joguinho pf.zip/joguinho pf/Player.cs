﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    public class Player
    {
        public string nome="";

        public  List<classedepersonagem> personagens;

        public static void turno()
        {
            do
            {

                //teste de velocidade do primeiro personagem

                Random rand = new Random(7);
                int d = 0;


                do
                {
                    //lista com os personagens com vida positiva e velocidade positiva
                    List<(double, string)> numeros = new List<(double a, string b)>
                    {
                    };
                    //parametros pra entrar na lista acima
                    do
                    {
                        //remover quando terminar
                        if (d < 3)
                        {
                            if (Program.jogador1.personagens[d].velocidade >= 1 && Program.jogador1.personagens[d].vida > 0)
                            {
                                numeros.Add((Program.jogador1.personagens[d].velocidade, Program.jogador1.personagens[d].numeros));

                            }
                        }
                        d++;
                    } while (d < 3);
                    d = 0;
                    do
                    {
                        //remover quando terminar

                        if (d<3)
                        { 
                             if (Program.jogador2.personagens[d].velocidade >= 1 && Program.jogador2.personagens[d].vida > 0)
                             {
                                 numeros.Add((Program.jogador2.personagens[d].velocidade, Program.jogador2.personagens[d].numeros));

                             }
                        }
                        d++;
                    } while (d < 3);

                    //fim dos parametros

                    //organizar as ordens dos numeros
                    numeros.Sort();

                    numeros.Reverse();

                   

                    //fim da organização

                    //variaveis pra dizer qual é o personagem a atacar e de qual jogador é
                    int i = 0;
                    object jogador = Program.jogador1;
                   
                    //pra cada personagem na lista numeros vai fazer uma vereficção pra saber qual o primeiro segundo etc da lista

                    foreach ((double a, string b) in numeros)
                    {
                        switch (b)
                        {
                            case "11":
                                jogador = Program.jogador1;
                                i = 0;

                                escolhas.escolha(jogador, i);

                                break;
                            case "12":
                                jogador = Program.jogador1;
                                i = 1;

                                escolhas.escolha(jogador, i);
                                break;
                            case "13":
                                jogador = Program.jogador1;
                                i = 2;

                                escolhas.escolha(jogador, i);
                                break;
                            case "21":
                                jogador = Program.jogador2;
                                i = 0;

                                escolhas.escolha(jogador, i);
                                break;
                            case "22":
                                jogador = Program.jogador2;
                                i = 1;

                                escolhas.escolha(jogador, i);
                                break;
                            case "23":
                                jogador = Program.jogador2;
                                i = 2;

                                escolhas.escolha(jogador, i);
                                break;

                        }


                    }
                } while ((Program.jogador1.personagens[0].velocidade >= 1 || Program.jogador1.personagens[1].velocidade >= 1 || Program.jogador1.personagens[2].velocidade >= 1) && (Program.jogador2.personagens[0].velocidade >= 1 || Program.jogador2.personagens[1].velocidade >= 1 || Program.jogador2.personagens[2].velocidade >= 1));

                //quando a velocidade de todos os personagens for menor que 1
                int w = 0;

                do
                {
                    if (Program.jogador1.personagens[w].name == "Assassino")
                    {
                        if (Program.jogador1.personagens[w].vida>0)
                        {
                            Program.jogador2.personagens[w].velocidade = Program.jogador2.personagens[w].velocidade + 1.5;
                        }
                       
                    }
                    else
                    {
                        if (Program.jogador1.personagens[w].vida > 0)
                        { Program.jogador2.personagens[w].velocidade = Program.jogador2.personagens[w].velocidade + 1;  }

                    }

                        w++;

                } while (w < 3);
                w= 0;
                do
                {
                    if (Program.jogador2.personagens[w].name == "Assassino")
                    {
                        if (Program.jogador2.personagens[w].vida > 0)
                        {
                            Program.jogador2.personagens[w].velocidade = Program.jogador2.personagens[w].velocidade + 1.5;
                        }
                    }
                    else
                    {
                        if (Program.jogador2.personagens[w].vida > 0)
                        { Program.jogador2.personagens[w].velocidade = Program.jogador2.personagens[w].velocidade + 1; }
                    }

                    w++;

                } while (w < 3);


            } while ((Program.jogador1.personagens[0].vida > 0 || Program.jogador1.personagens[1].vida > 0 || Program.jogador1.personagens[2].vida > 0) && (Program.jogador2.personagens[0].vida > 0 || Program.jogador2.personagens[1].vida > 0 || Program.jogador2.personagens[2].vida > 0));

            if (Program.jogador1.personagens[0].vida <= 0)
            {
               Console.WriteLine(Program.jogador2.nome + " VENCEU");
            }
            else 
            {
                Console.WriteLine(Program.jogador1.nome + " VENCEU");
            }

        }

        public Player()
        {
            personagens = new List<classedepersonagem>();
        }
       
    }
}
