﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    public class classedepersonagem
    {
        public string name;
        public int ataque;
        public int vida;
        public double velocidade;
        public int mana;
        public int escolha;
        public string numeros;
        public int buff;

        public static void Ataque(string a, int i, object jogador)
        {
           

            int c = int.Parse(a);



            if (jogador == Program.jogador1)
            {
                Program.jogador2.personagens[c].vida -= Program.jogador1.personagens[i].ataque;

            }
            else 
            {
                Program.jogador1.personagens[c].vida -= Program.jogador2.personagens[i].ataque;
            }
        }
    }
}