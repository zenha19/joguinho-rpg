﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    internal class Pocoes
    {
        public static void Velocidade (object a,int b) 
        {
            if (a == Program.jogador1)
            {
                string z;
                 double c;
                Console.WriteLine("a qual personagem deseja dar o buff");

                do
                {
                    Console.WriteLine("0 " + Program.jogador1.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador1.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador1.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");

                int y = int.Parse(z);

               
                
                     c= Program.jogador1.personagens[y].velocidade / 4 ;

                    Program.jogador1.personagens[y].velocidade = Program.jogador1.personagens[y].velocidade + c ;
                
               

                if (Program.jogador1.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z =Console.ReadLine();

                        if(z =="0")
                        {
                            Pocoes.Vida(Program.jogador1,b);
                        }
                        else if(z=="1")
                        {
                            Pocoes.Velocidade(Program.jogador1, b);
                        }
                        else 
                        {
                            Pocoes.Ataque(Program.jogador1, b);
                        }
                    } while(z != "0" &&  z != "1" && z!="2");


                
                }
                else 
                { 
                    if(Program.jogador1.personagens[b].name=="mago")
                    { Program.jogador1.personagens[b].mana += 2; }
                    else { Program.jogador1.personagens[b].mana += 1; }
                }
            }
            else 
            {
                string z;
                double c;
                Console.WriteLine("a qual personagem deseja dar o buff");
               

                do
                {
                    Console.WriteLine("0 " + Program.jogador2.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador2.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador2.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");
                int y = int.Parse(z);

               
                
                    c = Program.jogador2.personagens[y].velocidade / 4;

                    Program.jogador2.personagens[y].velocidade = Program.jogador2.personagens[y].velocidade + c;
                
              
                if (Program.jogador2.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z = Console.ReadLine();

                        if (z == "0")
                        {
                            Pocoes.Vida(Program.jogador2, b);
                        }
                        else if (z == "1")
                        {
                            Pocoes.Velocidade(Program.jogador2, b);
                        }
                        else
                        {
                            Pocoes.Ataque(Program.jogador2, b);
                        }
                    } while (z != "0" && z != "1" && z != "2");



                }
                else
                {
                    if (Program.jogador2.personagens[b].name == "mago")
                    { Program.jogador2.personagens[b].mana += 2; }
                    else { Program.jogador2.personagens[b].mana += 1; }
                }
            }
        
        
        }

        public static void Vida(object a,int b)
        {
            if (a == Program.jogador1)
            {
                string z;
               
                Console.WriteLine("a qual personagem deseja dar o buff");

                do
                {
                    Console.WriteLine("0 " + Program.jogador1.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador1.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador1.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");
                int y = int.Parse(z);

               
                
                    Program.jogador1.personagens[y].vida += 15; 
                
                
                if (Program.jogador1.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z = Console.ReadLine();

                        if (z == "0")
                        {
                            Pocoes.Vida(Program.jogador1, b);
                        }
                        else if (z == "1")
                        {
                            Pocoes.Velocidade(Program.jogador1, b);
                        }
                        else
                        {
                            Pocoes.Ataque(Program.jogador1, b);
                        }
                    } while (z != "0" && z != "1" && z != "2");



                }
                else
                {
                    if (Program.jogador1.personagens[b].name == "mago")
                    { Program.jogador1.personagens[b].mana += 2; }
                    else { Program.jogador1.personagens[b].mana += 1; }
                }
            }
            else
            {
                string z;
               
                Console.WriteLine("a qual personagem deseja dar o buff");

                do
                {
                    Console.WriteLine("0 " + Program.jogador2.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador2.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador2.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");

                int y = int.Parse(z);

                
                
                    Program.jogador2.personagens[y].vida += 15;
                
               
                if (Program.jogador2.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z = Console.ReadLine();

                        if (z == "0")
                        {
                            Pocoes.Vida(Program.jogador2, b);
                        }
                        else if (z == "1")
                        {
                            Pocoes.Velocidade(Program.jogador2, b);
                        }
                        else
                        {
                            Pocoes.Ataque(Program.jogador2, b);
                        }
                    } while (z != "0" && z != "1" && z != "2");



                }
                else
                {
                    if (Program.jogador2.personagens[b].name == "mago")
                    { Program.jogador2.personagens[b].mana += 2; }
                    else { Program.jogador2.personagens[b].mana += 1; }
                }
            }



        }
        public static void Ataque(object a, int b)
        {
            if (a == Program.jogador1)
            {
                string z;
                double c;
                Console.WriteLine("a qual personagem deseja dar o buff");

                do
                {
                    Console.WriteLine("0 " + Program.jogador1.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador1.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador1.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");

                int y = int.Parse(z);



                c = Program.jogador1.personagens[y].velocidade / 4;

                Program.jogador1.personagens[y].velocidade = Program.jogador1.personagens[y].velocidade + c;



                if (Program.jogador1.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z = Console.ReadLine();

                        if (z == "0")
                        {
                            Pocoes.Vida(Program.jogador1, b);
                        }
                        else if (z == "1")
                        {
                            Pocoes.Velocidade(Program.jogador1, b);
                        }
                        else
                        {
                            Pocoes.Ataque(Program.jogador1, b);
                        }
                    } while (z != "0" && z != "1" && z != "2");



                }
                else
                {
                    if (Program.jogador1.personagens[b].name == "mago")
                    { Program.jogador1.personagens[b].mana += 2; }
                    else { Program.jogador1.personagens[b].mana += 1; }
                }
            }
            else
            {
                string z;
                double c;
                Console.WriteLine("a qual personagem deseja dar o buff");


                do
                {
                    Console.WriteLine("0 " + Program.jogador2.personagens[0].name);
                    Console.WriteLine("1 " + Program.jogador2.personagens[1].name);
                    Console.WriteLine("2 " + Program.jogador2.personagens[2].name);
                    z = Console.ReadLine();
                } while (z != "0" && z != "1 " && z != "2");
                int y = int.Parse(z);



                c = Program.jogador2.personagens[y].velocidade / 4;

                Program.jogador2.personagens[y].velocidade = Program.jogador2.personagens[y].velocidade + c;


                if (Program.jogador2.personagens[b].mana == 1)
                {
                    z = "";

                    do
                    {

                        Console.WriteLine("escolha sua segunda poção");

                        Console.WriteLine("0 vida");
                        Console.WriteLine("1 velocidade");
                        Console.WriteLine("2 ataque");

                        z = Console.ReadLine();

                        if (z == "0")
                        {
                            Pocoes.Vida(Program.jogador2, b);
                        }
                        else if (z == "1")
                        {
                            Pocoes.Velocidade(Program.jogador2, b);
                        }
                        else
                        {
                            Pocoes.Ataque(Program.jogador2, b);
                        }
                    } while (z != "0" && z != "1" && z != "2");



                }
                else
                {
                    if (Program.jogador2.personagens[b].name == "mago")
                    { Program.jogador2.personagens[b].mana += 2; }
                    else { Program.jogador2.personagens[b].mana += 1; }
                }
            }


        }
    
    }
}
