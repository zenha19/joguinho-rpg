﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joguinho_pf
{
    internal class Mago: classedepersonagem
    {
        public Mago()
        {
            name = "mago";
            ataque= 25;
            vida= 100;
            velocidade=1;
            mana=2;
            escolha = 0;
            buff = 0;
        }
    }
}
